import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import DishesPage from './Pages/DishesPage';
import LiveMenuPage from './Pages/LiveMenuPage';
import ArchivePage from './Pages/ArchivePage';
import SignUp from './Pages/SignUp';
import SignIn from './Pages/SignIn';
import ConfirmSignUp from './Pages/ConfirmSignUp';
import { AuthProvider, useAuth } from './context/AuthContext';

// Protect Routes: Only Allow Signed-In Users
const ProtectedRoute = ({ element }) => {
  const { user, loading } = useAuth();

  if (loading) return <div>Loading...</div>; // ✅ Prevent flickering
  return user ? element : <Navigate to="/signin" />;
};

const AppContent = () => {
  const { user } = useAuth();
  const isAuthPage = ["/signin", "/signup", "/confirm"].includes(window.location.pathname);

  return (
    <Router>
      {!isAuthPage && user && <Navbar />} {/* ✅ Hide Navbar when signed out */}
      <Routes>
        <Route path="/" element={user ? <Navigate to="/dishes" /> : <Navigate to="/signin" />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/signin" element={<SignIn />} />
        <Route path="/confirm" element={<ConfirmSignUp />} />
        <Route path="/dishes" element={<ProtectedRoute element={<DishesPage />} />} />
        <Route path="/menu" element={<ProtectedRoute element={<LiveMenuPage />} />} />
        <Route path="/archive" element={<ProtectedRoute element={<ArchivePage />} />} />
      </Routes>
    </Router>
  );
};

const App = () => (
  <AuthProvider>
    <AppContent />
  </AuthProvider>
);

export default App;
