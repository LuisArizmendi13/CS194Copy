import React, { createContext, useContext, useEffect, useState } from "react";
import { CognitoUserPool, CognitoUser, AuthenticationDetails } from "amazon-cognito-identity-js";
import { userPool } from "../aws-config";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // ✅ Retrieve session when app loads or refreshes
  useEffect(() => {
    const fetchSession = async () => {
      const cognitoUser = userPool.getCurrentUser();

      if (!cognitoUser) {
        console.log("❌ No active session found.");
        setUser(null);
        setLoading(false);
        return;
      }

      cognitoUser.getSession((err, session) => {
        if (err || !session.isValid()) {
          console.log("❌ Invalid session or error fetching session.");
          setUser(null);
        } else {
          console.log("✅ User session found:", cognitoUser.getUsername());
          setUser(cognitoUser);
        }
        setLoading(false);
      });
    };

    fetchSession();
  }, []);

  // ✅ Sign In Function
  const signIn = (email, password) => {
    return new Promise((resolve, reject) => {
      const cognitoUser = new CognitoUser({ Username: email, Pool: userPool });
      const authenticationDetails = new AuthenticationDetails({
        Username: email,
        Password: password,
      });

      cognitoUser.authenticateUser(authenticationDetails, {
        onSuccess: (session) => {
          console.log("✅ Signed in successfully:", cognitoUser.getUsername());
          setUser(cognitoUser);
          resolve(session);
        },
        onFailure: (err) => {
          console.error("❌ Sign-in error:", err);
          reject(err);
        },
      });
    });
  };

  // ✅ Sign Out Function
  const signOut = () => {
    const cognitoUser = userPool.getCurrentUser();

    if (cognitoUser) {
      cognitoUser.signOut();
    }

    // ✅ Fully clear Cognito session storage
    const clientId = userPool.getClientId();
    localStorage.removeItem(`CognitoIdentityServiceProvider.${clientId}.LastAuthUser`);
    localStorage.removeItem(`CognitoIdentityServiceProvider.${clientId}.${user?.getUsername()}.accessToken`);
    localStorage.removeItem(`CognitoIdentityServiceProvider.${clientId}.${user?.getUsername()}.idToken`);
    localStorage.removeItem(`CognitoIdentityServiceProvider.${clientId}.${user?.getUsername()}.refreshToken`);
    sessionStorage.clear();

    setUser(null);
    console.log("✅ User signed out and session cleared.");
  };

  return (
    <AuthContext.Provider value={{ user, signIn, signOut, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
