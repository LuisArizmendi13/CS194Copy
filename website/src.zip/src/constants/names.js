export const APP_NAME = "Menu Venue";
export const NAV_LINKS = [
  { name: "Home", path: "/" },
  { name: "My Menus", path: "/menus" }, 
  {name: "Live Menu", path:"menu"},
  { name: "Dishes", path: "/dishes" }, 
  {name: "Analytics", path:"/analytics"}, 
  {name: 'Archive', path:"/archive"}
];
